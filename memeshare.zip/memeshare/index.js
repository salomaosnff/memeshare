const app = require('./app');

app.listen(8000, () => console.log("Servidor em execução..."));